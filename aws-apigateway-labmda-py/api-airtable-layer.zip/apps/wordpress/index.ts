// Copyright 2016-2019, Pulumi Corporation.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import * as awsx from "@pulumi/awsx";
import * as k8s from "@pulumi/kubernetes";
import { config } from "./config";



// Create a k8s provider.
const provider = new k8s.Provider("provider", {
    kubeconfig: config.kubeconfig,
    namespace: config.appsNamespaceName,
});

// Deploy the latest version of the stable/wordpress chart.
const wordpress = new k8s.helm.v3.Chart("wpdev", {
    fetchOpts: {
        repo: "https://charts.bitnami.com/bitnami/",
    },
    chart: "wordpress",
    version: "9.6.0",
    transformations: [
        (obj: any) => {
            // Do transformations on the YAML to set the namespace
            if (obj.metadata) {
                obj.metadata.namespace = config.appsNamespaceName;
            }
        },
    ],
}, { provider: provider });

// Export the public IP for WordPress.
const frontend = wordpress.getResource("v1/Service", "wpdev-wordpress");
export const frontendIp = frontend.status.loadBalancer.ingress[0].ip;
//
// // Deploy the bitnami/wordpress chart.
// const wordpress = new k8s.helm.v3.Chart("wpdev", {
//     version: "9.6.0",
//     chart: "wordpress",
//     fetchOpts: {
//         repo: "https://charts.bitnami.com/bitnami",
//     },
// });

// Get the status field from the wordpress service, and then grab a reference to the ingress field.
// const frontend = wordpress.getResourceProperty("v1/Service", "wpdev-wordpress", "status");
// const ingress = frontend.loadBalancer.ingress[0];

// // Export the public IP for Wordpress.
// // Depending on the k8s cluster, this value may be an IP address or a hostname.
// export const frontendIp = ingress.apply(x => x.ip ?? x.hostname);