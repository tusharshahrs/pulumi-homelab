// Copyright 2016-2019, Pulumi Corporation.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import * as awsx from "@pulumi/awsx";
import * as k8s from "@pulumi/kubernetes";
import { config } from "./config";

// Create a repository.
const repo = new awsx.ecr.Repository("test-node");

// Build a Docker image from a local Dockerfile context in the
// './node-app' directory, and push it to the registry.
const customImage = "node-app";
const appImage = repo.buildAndPushImage(`./${customImage}`);

// Create a k8s provider.
const provider = new k8s.Provider("provider", {
    kubeconfig: config.kubeconfig,
    namespace: config.appsNamespaceName,
});

// Create a Deployment of the built container.
const appLabels = { app: customImage };
const appDeployment = new k8s.apps.v1.Deployment("app", {
    spec: {
        selector: { matchLabels: appLabels },
        replicas: 1,
        template: {
            metadata: { labels: appLabels },
            spec: {
                containers: [{
                    name: customImage,
                    image: appImage,
                    ports: [{name: "http", containerPort: 80}],
                    resources: { requests: { cpu: "100m", memory: "100Mi" } },
                }],
            }
        },
    }
}, { provider: provider });


// Create a Service for Node App.
const appSvc = new k8s.core.v1.Service("node-app", {
    spec: {
        type: "LoadBalancer",
        externalTrafficPolicy: "Cluster",
        ports: [
            {
                name: "http",
                port: 80,
                targetPort: "http"
            }
        ],
        selector: {
            app: customImage
        }
    }
}, { provider: provider });

// Export the Service name and public LoadBalancer Endpoint
export const serviceName = appSvc.metadata.apply(m => m.name);
export const serviceHostname = appSvc.status.apply(s => s.loadBalancer.ingress[0].hostname);
